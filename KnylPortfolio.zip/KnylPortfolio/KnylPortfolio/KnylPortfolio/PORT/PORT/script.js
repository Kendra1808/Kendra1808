let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');

menuIcon.onclick = () => {
    menuIcon.classList.toggle('bx-x');
    navbar.classList.toggle('active');
}














let sections = document.querySelectorAll('section');
let navLinks = document.querySelectorAll('header nav a');

document.addEventListener("DOMContentLoaded", function() {
    console.log("DOM loaded!"); // Debugging statement

    const sections = document.querySelectorAll("section");
    const navLinks = document.querySelectorAll(".navbar a");
    console.log("Sections:", sections); // Debugging statement
    console.log("Nav Links:", navLinks); // Debugging statement

    window.addEventListener("scroll", function() {
        console.log("Scrolling!"); // Debugging statement

        const scrollPosition = window.scrollY;

        sections.forEach(function(section) {
            const offset = section.offsetTop - 150; // Adjust according to your layout
            const height = section.offsetHeight;
            const id = section.getAttribute("id");
            const navLink = document.querySelector('header .navbar a[href="#' + id + '"]');

            if (scrollPosition >= offset && scrollPosition < offset + height) {
                navLinks.forEach(function(link) {
                    link.classList.remove("active");
                });
                navLink.classList.add("active");
            }
        });
    });
});


let header = document.querySelector('header');

header.classList.toggle('sticky', window.scrollY > 100);


var typed = new Typed(".multiple-text", {
    strings: ["Frontend Developer", "UIUX Designer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
})

menuIcon.classList.remove('bx-x');
navbar.classList.remove('active');

ScrollReveal({
    reset: true,
    distance: '80px',
    duration: 2000,
    delay: 200

});

ScrollReveal().reval('home-content, .heading', { origin: 'top'});




// Initialize ScrollReveal
ScrollReveal().reveal('.home-content', {
    delay: 200,
    distance: '50px',
    origin: 'bottom',
    duration: 1000,
    easing: 'ease-in-out',
    interval: 200
});

ScrollReveal().reveal('.social-media a', {
    delay: 400,
    distance: '50px',
    origin: 'bottom',
    duration: 1000,
    easing: 'ease-in-out',
    interval: 200
});

ScrollReveal().reveal('.btn', {
    delay: 600,
    distance: '50px',
    origin: 'bottom',
    duration: 1000,
    easing: 'ease-in-out',
    interval: 200
});
